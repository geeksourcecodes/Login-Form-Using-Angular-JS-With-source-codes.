<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <meta name="keywords" content="login,loginform,Nikhil,freelancer">
  <meta name="author" content="Nikhil Bhalerao">
  <title>AngularJs: Login Form Validation</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css'>
<link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<br><br><br><br><br><br><br>
<form class="form-horizontal" action="check_login.php" method="post" name="loginForm" novalidate ng-app="formValidationApp" ng-controller="ValidationCtrl">
  <div class="form-heading">
    <h2>Sign In using Angular JS</h2>
  </div><br><br>
  <div class="form-group" ng-class="{'has-error': loginForm.email.$invalid && loginForm.email.$dirty, 'has-success': loginForm.email.$valid }">
    <input type="email" class="form-control" placeholder="Email" name="email" ng-model="user.email" required/>
    <p class="help-block" ng-if="loginForm.email.$invalid && loginForm.email.$dirty">Please Enter a valid email address</p>
  </div>
  <div class="form-group" ng-class="{'has-error': loginForm.password.$invalid && loginForm.password.$dirty, 'has-success': loginForm.password.$valid}">
    <input type="password" class="form-control" placeholder="Password" name="password" ng-model="user.password" ng-minLength="8" required/>
    <p class="help-block" ng-if="loginForm.password.$invalid && loginForm.password.$dirty">Please Enter at least 8 characters</p>
  </div><br><br>
  <button class="btn btn-default pull-right" name="sign_in" type="submit" ng-disabled="loginForm.emails.$invalid || loginForm.password.$invalid">Sign In</button>
</form>
<!-- partial --><br><br><br>
<footer>
  <center> @ <?php echo date('Y'); ?><a href="https://www.youtube.com/channel/UCnTEh3OFRS1wP0-Wqm2D-rA?sub_confirmation=1"> Coded by Nikhil Bhalerao</a></center>
  
</footer>
  <script src='angular.min.js'></script>
  <script  src="./script.js"></script>

</body>
</html>