angular.module('formValidationApp', [])
.controller('ValidationCtrl', function (){

})