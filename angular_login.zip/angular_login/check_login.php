<?php

if(isset($_POST['sign_in']))
{
	$user=$_POST['email'];
	$pass=$_POST['password'];
	if($user=='ndbhalerao91@gmail.com' && $pass=='nikhil@123')
	{
		$res=1;
		$msg='Login Success';
	}
	else
	{
		$res=0;
		$msg='Invalid User name and password';
	}
}
else
{
	$res=0;
	$msg='Login First';
}
?>
<link rel="stylesheet" href="popup_style.css">
<?php if($res==1){ ?>
	<div class="popup popup--icon -success js_success-popup popup--visible">
<div class="popup__background"></div>
<div class="popup__content">
<h3 class="popup__content__title">Success</h3>
<p><?php echo $msg; ?></p>
<a href="dashboard.php"><button class="button button--success" data-for="js_error-popup">Ok</button></a>
</div>
</div>
<?php }else{ ?>
	<div class="popup popup--icon -error js_error-popup popup--visible">
<div class="popup__background"></div>
<div class="popup__content">
<h3 class="popup__content__title">Error</h3>
<p><?php echo $msg; ?></p>
<p>
      <a href="index.php"><button class="button button--error" data-for="js_error-popup">Close</button></a>
    </p>
  </div>
</div>
<?php } ?>

